namespace ExtremeFit.Repository.DTOs
{
    public class ValidarDicaDto
    {
        public bool Valido { get; set; }
    }
}