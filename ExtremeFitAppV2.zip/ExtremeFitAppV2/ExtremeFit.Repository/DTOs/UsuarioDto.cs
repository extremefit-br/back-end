namespace ExtremeFit.Repository.DTOs
{
    public class UsuarioDto
    {
        public string Email { get; set; }
        public string Senha { get; set; }
        public string Rfid { get; set; }
        public string Digital { get; set; }
    }
}