namespace ExtremeFit.Repository.DTOs
{
    public class IotDto
    {
        public string Rfid { get; set; }
        public string Digital { get; set; }
    }
}