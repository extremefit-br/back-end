namespace ExtremeFit.Repository.DTOs
{
    public class TesteDto
    {
        
    }
}