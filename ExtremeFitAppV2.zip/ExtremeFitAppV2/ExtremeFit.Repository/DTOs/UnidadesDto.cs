using System.Collections.Generic;

namespace ExtremeFit.Repository.DTOs
{
    public class UnidadesDto
    {
        public int[] UnidadesFavoritasId { get; set; }
    }
}